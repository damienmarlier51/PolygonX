from setuptools import setup

setup(
	name='polygonX',
	version='0.1',
	packages = ['polygonX'],
	description = '',
	author = 'Damien Marlier',
	author_email = 'damien.marlier@hotmail.fr',
	url = 'https://github.com/damienmarlier/polygonX',
	download_url = 'https://github.com/damienmarlier/polygonX/archive/0.1.tar.gz',
	keywords = ['testing'],
	classifiers = [],
) 
